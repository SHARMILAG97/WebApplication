package com.revature.exception;

public class ValidatorException extends Exception {
	public ValidatorException(String message) {
		super(message);
	}

}
